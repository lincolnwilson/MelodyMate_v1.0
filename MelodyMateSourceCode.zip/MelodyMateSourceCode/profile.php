<?php
	session_start();
	if(isset($_GET["user"]) AND isset($_SESSION["username"])){
		$signedin = $_SESSION["username"];
		include_once('header.php');
		
		echo "
			<div class='text-center'>
			<div class='mx-auto' style='width: 100%;'>";
		$username = $_GET['user'];
		$identity = "profilepic";
		$followingyeornay = "";
		$checkiffollow = "SELECT content FROM content WHERE list_id = ? AND content = ?";
		$connection = mysqli_connect("localhost", "root", "MB1Uf5XDVr5MhN", "melody_mate");
		 
		// Check connection
		if($connection === false){
			die("ERROR: Could not connect. " . mysqli_connect_error());
		}
		$followinglist = $signedin."_following";
		$followerlist = $username."_followers";
		$followidfinder = "SELECT list_id FROM list WHERE name = ?";
		$stmt = $connection->prepare($followidfinder); 
		$stmt->bind_param("s",$followinglist);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$followingid = $row['list_id'];
		}
		$stmtchk = $connection->prepare($checkiffollow); 
		$stmtchk->bind_param("ss",$followingid,$username);
		$stmtchk->execute();
		$result = $stmtchk->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$followingyeornay = $row['content'];
		}
		$stmt2 = $connection->prepare($followidfinder); 
		$stmt2->bind_param("s",$followerlist);
		$stmt2->execute();
		$result = $stmt2->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$followerid = $row['list_id'];
		}
		$sql = "SELECT name FROM files WHERE username = ? AND identity = ?";
		$stmt = $connection->prepare($sql); 
		$stmt->bind_param("ss", $username, $identity);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$profilepic = $row['name'];
		}
		$identity = "headerpic";
		$sql = "SELECT name FROM files WHERE username = ? AND identity = ?";
		$stmt = $connection->prepare($sql); 
		$stmt->bind_param("ss", $username, $identity);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$headerpic = $row['name'];
		}
		$sql = "SELECT profile_bio FROM user WHERE username = ?";
		$stmt = $connection->prepare($sql); 
		$stmt->bind_param("s", $username);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$bio = $row['profile_bio'];
		}
		$albumlocationslist = [];
		$num = 0;
		$albumlocations = "SELECT album_location FROM album WHERE username = ? ORDER BY timestamp desc;";
		$stmt = $connection->prepare($albumlocations); 
		$stmt->bind_param("s", $username);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$albumlocationslist[$num] = $row['album_location'];
			$albumlocationslist[$num] = str_replace("/var/www/html/melodymate/","",$albumlocationslist[$num]);
			$num = $num +1;
		}
		$albumartlist = [];
		$albumartfilelist =  [];
		$num = 0;
		$albumarts = "SELECT album_art FROM album WHERE username = ? ORDER BY timestamp desc;";
		$stmt = $connection->prepare($albumarts); 
		$stmt->bind_param("s", $username);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$albumartlist[$num] = $row['album_art'];
			$num = $num +1;
		}
		$numoffiles = $num;
		$num = 0;
		$num2 = 0;
		while ($num2 != $numoffiles){
			$albumartfiles = "SELECT name FROM files WHERE username = ? AND id = ?;";
			$stmt = $connection->prepare($albumartfiles); 
			$stmt->bind_param("ss", $username, $albumartlist[$num2]);
			$stmt->execute();
			$result = $stmt->get_result(); // get the mysqli result
			while ($row= $result->fetch_assoc()) {
				$albumartfilelist[$num] = $row['name'];
				$num = $num +1;
			}
			$num2 = $num2 +1;
		}
		$num = 0;
			//NEWS FEED QUERIES
		$followlist = $username."_following";
		$friendslistfinder = "SELECT list_id FROM list WHERE name = ?";
		$stmt = $connection->prepare($friendslistfinder); 
		$stmt->bind_param("s", $followlist);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$list_id = $row['list_id'];
		}
		$xnum = 0;
		$following = [];
		$followingfinder = "SELECT content FROM content WHERE list_id = ?";
		$stmt = $connection->prepare($followingfinder); 
		$stmt->bind_param("s", $list_id);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$following[$xnum] = $row['content'];
			$xnum = ($xnum+1);
		}
		$numfollowing = $xnum;
		$xnum = 0;
		$znum = 0;
		$posts = array();
		$num = 0;
		
		$followingpostfinder = "SELECT username, post_content, post_datetime FROM post WHERE username = ? ORDER BY post_datetime desc;";
		$stmt = $connection->prepare($followingpostfinder); 
		$stmt->bind_param("s", $username);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			array_push($posts, $row['username']."=>".$row['post_content']."=>".$row['post_datetime']);
			$num = $num +1;
		}
		
		$numposts = $num;
		$num = 0;
		$znum = 0;
		// Following List id
		$listname = $username."_following";
		$sql = "SELECT list_id FROM list WHERE name = ?";
		$stmt = $connection->prepare($sql); 
		$stmt->bind_param("s", $listname);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$listid = $row['list_id'];
		}
		// Follower List id
		$listname = $username."_followers";
		$sql = "SELECT list_id FROM list WHERE name = ?";
		$stmt = $connection->prepare($sql); 
		$stmt->bind_param("s", $listname);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$listid2 = $row['list_id'];
		}
		// Following Count
		$followingCount = 0;
		$sql = "SELECT content FROM content WHERE list_id = ?";
		$stmt = $connection->prepare($sql); 
		$stmt->bind_param("s", $listid);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$followingCount = $followingCount +1;
		}
		// Follower Count
		$followerCount = 0;
		$sql = "SELECT content FROM content WHERE list_id = ?";
		$stmt = $connection->prepare($sql); 
		$stmt->bind_param("s", $listid2);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$followerCount = $followerCount +1;
		}
		// Follower Count + List Creator
		$followerCount = 0;
		$followers = [];
		$sql = "SELECT content FROM content WHERE list_id = ?";
		$stmt = $connection->prepare($sql); 
		$stmt->bind_param("s", $listid2);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			array_push($followers, $row['content']);
			$followerCount = $followerCount +1;
		}
		$follownum = 0;
		$userfinder = 'SELECT username, profile_pic FROM user WHERE username = ?;';
		$profilepicfinder = 'SELECT name FROM files WHERE id = ?;';
		$followingOutput = "";
		while ($follownum != $followingCount){
			$search_entry = $following[$follownum];
			$stmt = $connection->prepare($userfinder); 
			if (!$stmt) {
				throw new Exception($connection->error, $connection->errno);
			}
			$stmt->bind_param('s', $search_entry);
			if (!$stmt->execute()) {
				throw new Exception($stmt->error, $stmt->errno);
			}
			$result = $stmt->get_result(); // get the mysqli result
			if ($result->num_rows > 0) {
				while ($row= $result->fetch_assoc()) {
					$usernames = $row['username'];
					$profilepics = $row['profile_pic'];
					$stmt2 = $connection->prepare($profilepicfinder);
					$stmt2->bind_param('i', $profilepics);
					$stmt2->execute();
					$result2= $stmt2->get_result();
					while($row2=$result2->fetch_assoc()) {
						$filename = $row2['name'];
					}
					$followingOutput = $followingOutput.'
						<div class="media">
							<img src="/melodymate/profilepics/'.$usernames.'/'.$filename.'" class="mr-2 rounded-circle" style="width:30px; height:30px;">
							<div class="media-body">
							'.$usernames.'
							<a href="/melodymate/profile.php?user='.$usernames.'">View Profile</a>
							</div>
						</div>
					<br><hr/><br>';
				}
			}
			$follownum = $follownum +1;
		}
		$followersOutput = "";
		$follownum = 0;
		while ($follownum != $followerCount){
			$search_entry = $followers[$follownum];
			$stmt = $connection->prepare($userfinder); 
			if (!$stmt) {
				throw new Exception($connection->error, $connection->errno);
			}
			$stmt->bind_param('s', $search_entry);
			if (!$stmt->execute()) {
				throw new Exception($stmt->error, $stmt->errno);
			}
			$result = $stmt->get_result(); // get the mysqli result
			if ($result->num_rows > 0) {
				while ($row= $result->fetch_assoc()) {
					$usernames = $row['username'];
					$profilepics = $row['profile_pic'];
					$stmt2 = $connection->prepare($profilepicfinder);
					$stmt2->bind_param('i', $profilepics);
					$stmt2->execute();
					$result2= $stmt2->get_result();
					while($row2=$result2->fetch_assoc()) {
						$filename = $row2['name'];
					}
					$followersOutput = $followersOutput.'
						<div class="media">
							<img src="/melodymate/profilepics/'.$usernames.'/'.$filename.'" class="mr-2 rounded-circle" style="width:30px;height:30px;">
							<div class="media-body">
							'.$usernames.'
							<a href="/melodymate/profile.php?user='.$usernames.'">View Profile</a>
							</div>
						</div>
					<br><hr/><br>';
				}
			}
			$follownum = $follownum +1;
		$followersOutput = $followersOutput."";
		}
		// Audio Selector
		$audioPlayer = [];
		$albumnums = [];
		$albumnumssql = "SELECT album_num FROM album WHERE username = ?;";
		$stmt = $connection->prepare($albumnumssql); 
		$stmt->bind_param("s", $username);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			array_push($albumnums, $row['album_num']);
		}
		$num = 0;
		while ($num != $numoffiles) {
			//Get Album Folder
			$albumlocations = "SELECT album_location FROM album WHERE username = ? AND album_num = ?;";
			$stmt = $connection->prepare($albumlocations); 
			$stmt->bind_param("si", $username, $albumnums[$num]);
			$stmt->execute();
			$result = $stmt->get_result(); // get the mysqli result
			while ($row= $result->fetch_assoc()) {
				$albumlocation = $row['album_location'];
				$albumlocation = str_replace("/var/www/html","",$albumlocation);
			}
			//Get tracks
			$trackfiles = [];
			$numbertracksfinder = "SELECT numoftracks FROM album WHERE username = ? AND album_num = ?;";
			$stmt = $connection->prepare($numbertracksfinder); 
			$stmt->bind_param("si", $username, $albumnums[$num]);
			$stmt->execute();
			$result = $stmt->get_result(); // get the mysqli result
			while ($row= $result->fetch_assoc()) {
				$numberoftracks = $row['numoftracks'];
			}
			$wnum = 0;
			$trackfilefinder = "SELECT media_file FROM media WHERE username = ? AND album_num = ?;";
			$stmt = $connection->prepare($trackfilefinder); 
			$stmt->bind_param("si", $username, $albumnums[$num]);
			$stmt->execute();
			$result = $stmt->get_result(); // get the mysqli result
			while ($row= $result->fetch_assoc()) {
				array_push($trackfiles, $row['media_file']);
			}
			$trackstring = "";
			while ($wnum != $numberoftracks) {
				//Get Track File
				$trackfilesql = "SELECT name FROM files WHERE username = ? AND id = ?;";
				$stmt = $connection->prepare($trackfilesql); 
				$file = $trackfiles[$wnum];
				$stmt->bind_param("si", $username, $file);
				$stmt->execute();
				$result = $stmt->get_result(); // get the mysqli result
				while ($row= $result->fetch_assoc()) {
					$trackfile = $row['name'];
				}
				//Get Track Name
				$namefinder = "SELECT media_name FROM media WHERE username = ? AND album_num = ? AND track_num = ?;";
				$stmt = $connection->prepare($namefinder); 
				$b = $wnum+1;
				$stmt->bind_param("sii", $username, $albumnums[$num], $b);
				$stmt->execute();
				$result = $stmt->get_result(); // get the mysqli result
				while ($row= $result->fetch_assoc()) {
					$trackname = $row['media_name'];
				}
				//Append String
				$trackstring = $trackstring.$trackname.' by '.$username.'
				<br><audio controls style="width:250px; height:50px;">
				  <source src="'.$albumlocation.$trackfile.'" type="audio/mpeg">
				Your browser does not support the audio element.
				</audio><br>';
				$wnum = $wnum+1;
			}
			$audioPlayer[$num] =
			'
				<div class="text-left" style="width:700px;">
					'.$trackstring.'
				</div>
			';
			$num = $num+1;
		}
		$div = '<div style="height:250px;overflow-y:auto;">';
		echo "
			<br>
			<div id='outerContainer'>
				<div id='containerA'>
					<div class='text-center'>	
						<br>
						<img class='card-img-top' src='/melodymate/headerpics/".$username."/".$headerpic."' alt='' style='width:100%; height:140%;'>
					</div>
				</div>
					
				<div id='containerB'>
					<div class='text-center'>
						<img class='rounded-circle' src='/melodymate/profilepics/".$username."/".$profilepic."' style='width:70px; height:70px;'>
					</div>
				</div>
				<div id='rest-of-page'>
					<div class='text-center'>
						<br>
						<h2>".$username."</h2>
						<p>".$bio."</p>";
						echo "
						<a title='Following' tabindex='0' role='button' data-toggle='popover' data-trigger='focus' data-placement='left' data-html='true' data-content='".$div.$followingOutput."</div>'><button type='button' class='btn btn-primary btn-sm'>Following (".$followingCount.")</button></a>
						<a title='Followers' tabindex='0' role='button' data-toggle='popover' data-trigger='focus' data-placement='right' data-html='true' data-content='".$div.$followersOutput."</div>'><button type='button' class='btn btn-primary btn-sm'>Followers (".$followerCount.")</button></a>";
						echo"
				  </div>
				</div>
			</div>
			</div>	<br><br>";
			if(strlen($bio) > "60") {
			        echo "<br>";
			}
			if(strlen($bio) > "120"){
				echo "<br>";
			}
			if(strlen($bio) > "180"){
				echo "<br>";
			}
				if ($username !== $signedin AND $followingyeornay !== $username){
						echo "
						<form action='' method='post'>
							<br><input type='text' name='follow' value='1' style='display:none;'>
							<input type='submit' class='btn btn-info' value='Follow User'>
						</form>
						";
					}
			
		if(isset($_POST['follow'])){
			$follow = $_POST['follow'];
			if($follow == 1){
				$following = "INSERT INTO content(content,list_id) values('$username','$followingid');";
				if(mysqli_query($connection, $following)){
					echo "";
				} 
				else{
					echo "ERROR: Could not able to execute $following. " . mysqli_error($connection);
				}
				$follower = "INSERT INTO content(content,list_id) values('$signedin', '$followerid');";
				if(mysqli_query($connection, $follower)){
					echo"<script>window.location = '/melodymate/profile.php?user=".$username."'</script>";
				} 
				else{
					echo "ERROR: Could not able to execute $following. " . mysqli_error($connection);
				}
			}
		}
		$highlightedmedia = "album";		
		echo "<div class='text-center'><form action='' method='post'>
				<select placeholder='View Media' name='mediatype'>
					<option value=''>View Media</option>
					<option value='album'>Album</option>
					<option value='track'>Track</option>
				</select>
				<input type='submit' value='Select'>
			</form></div>
			";
			if(isset($_POST['mediatype'])){
				$highlightedmedia = $_POST['mediatype'];
			}
			if($highlightedmedia == "album"){
if(isset($albumartfilelist[0])){
            echo"<div class='mx-auto text-center'><div id='firstrowcarousel' class='carousel slide' data-ride='carousel'>
                     <div class='carousel-inner'>
                        <div class='carousel-item active'>
                               <a  data-toggle='popover' role='button'  data-content='".$audioPlayer[0]."'>
                               <img src='/melodymate/".$albumlocationslist[0].$albumartfilelist[0]."' style='width:250px;height:250px;'>
                                </a>
                         </div>
                          ";
}
if(isset($albumartfilelist[1])){
            echo "
						<div class='carousel-item'>
								<a  data-toggle='popover' role='button'  data-content='".$audioPlayer[1]."'>
                                <img src='/melodymate/".$albumlocationslist[1].$albumartfilelist[1]."' style='width:250px;height:250px;'>
                                </a>            
                        </div>
                          ";
}
if(isset($albumartfilelist[2])){
            echo "
                        <div class='carousel-item'>
                                <a  data-toggle='popover' role='button'  data-content='".$audioPlayer[2]."'>
								<img src='/melodymate/".$albumlocationslist[2].$albumartfilelist[2]."' style='width:250px;height:250px;'>
								</a>            
						</div>
						";
}
if(isset($albumartfilelist[3])){
			echo "
						<div class='carousel-item'>
								<a  data-toggle='popover' role='button'   data-content='".$audioPlayer[3]."'>
								<img src='/melodymate/".$albumlocationslist[3].$albumartfilelist[3]."' style='width:250px;height:250px;'>
								</a>            
						</div>
						";
}
if(isset($albumartfilelist[4])){
			echo "
						<div class='carousel-item'>
								<a  data-toggle='popover' role='button'   data-content='".$audioPlayer[4]."'>
								<img src='/melodymate/".$albumlocationslist[4].$albumartfilelist[4]."' style='width:250px;height:250px;'>
								</a>            
						</div>
						";
}
if(isset($albumartfilelist[5])){
			echo "
						<div class='carousel-item'>
								<a  data-toggle='popover' role='button'   data-content='".$audioPlayer[5]."'>
								<img src='/melodymate/".$albumlocationslist[5].$albumartfilelist[5]."' style='width:250px;height:250px;'>
								</a>            
						</div>
						";
}
if(isset($albumartfilelist[6])){
			echo "
						<div class='carousel-item'>
								<a  data-toggle='popover' role='button'   data-content='".$audioPlayer[6]."'>
								<img src='/melodymate/".$albumlocationslist[6].$albumartfilelist[6]."' style='width:250px;height:250px;'>
								</a>            
						</div>
						";
}
if(isset($albumartfilelist[7])){
			echo "
						<div class='carousel-item'>
								<a  data-toggle='popover' role='button'   data-content='".$audioPlayer[7]."'>
								<img src='/melodymate/".$albumlocationslist[7].$albumartfilelist[7]."' style='width:250px;height:250px;'>
								</a>            
						</div>
						";
}     
if(isset($albumartfilelist[0])){
		echo "</div>
		<a class='carousel-control-prev' href='#firstrowcarousel' role='button' data-slide='prev'>
				<span class='carousel-control-prev-icon' aria-hidden='true'></span>
				<span class='sr-only'>Previous</span>
		</a>
		<a class='carousel-control-next' href='#firstrowcarousel' role='button' data-slide='next'>
				<span class='carousel-control-next-icon' aria-hidden='true'></span>
				<span class='sr-only'>Previous</span>
		</a>
		</div>";
}
}
	echo "
		<br><hr/>";
		if(!empty($posts)){
			$num = 0;
			$identity = "profilepic";
			echo "<div class='text-center'><div class='mx-auto' style='width: 60%;'><div class=''>";
			while ($num != $numposts){
				$usernamea = substr($posts[$num], 0, strpos($posts[$num], '=>', 0));
				$stringx = str_replace($usernamea."=>", "",$posts[$num]);
				$thepost = substr($stringx, 0, strpos($stringx, '=>', 0));
				$timestamp = str_replace($thepost."=>", "",$stringx);
				$sql = "SELECT name FROM files WHERE username = ? AND identity = ?";
				$stmt = $connection->prepare($sql); 
				$stmt->bind_param("ss", $usernamea, $identity);
				$stmt->execute();
				$result = $stmt->get_result(); // get the mysqli result
				while ($row= $result->fetch_assoc()) {
					$profilepica = $row['name'];
				}
				$comments = [];
				$postnosql = "SELECT post_num FROM post WHERE username = ? AND post_datetime = ?";
				$stmt = $connection->prepare($postnosql); 
				$stmt->bind_param("ss", $usernamea, $timestamp);
				$stmt->execute();
				$result = $stmt->get_result(); // get the mysqli result
				while ($row= $result->fetch_assoc()) {
					$postnumber  = $row['post_num'];
				}
				$sql = "SELECT message, sender, message_datetime FROM comment WHERE recipient = ? AND post_num = ?";
				$stmt = $connection->prepare($sql); 
				$stmt->bind_param("ss", $usernamea, $postnumber);
				$stmt->execute();
				$result = $stmt->get_result(); // get the mysqli result
				while ($row= $result->fetch_assoc()) {
					$msgdatetime = $row['message_datetime'];
					$msg = $row['message'];
					$sndr = $row['sender'];
					//Get profilepic
					$picfindingmodule = "SELECT name FROM files WHERE username = ? AND identity = ?";
					$stmt9000 = $connection->prepare($picfindingmodule); 
					$stmt9000->bind_param("ss", $sndr, $identity);
					$stmt9000->execute();
					$result3 = $stmt9000->get_result(); // get the mysqli result
					while ($row3= $result3->fetch_assoc()) {
						$profilepicb = $row3['name'];
					}
					$string = "
					<div class='media mt-3'>
					  <div class='mr-3'>
					  <img class='rounded-circle' src='/melodymate/profilepics/".$sndr."/".$profilepicb."' alt='Profilepic' style='width:50px; height:50px;'>
					  </div>
					  <div class='media-body'>
						<h5 class='mt-0'>".$sndr."</h5>
						<p>".$msg."</p>
					    <small>".$msgdatetime."</small>
					  </div>
					</div>
					";
					array_push($comments, $string);
				}
      echo "
                                <div>
                                  <img class='rounded-circle' src='/melodymate/profilepics/".$usernamea."/".$profilepica."' alt='Profilepic' style='width:60px; height:60px;'>
                                        <div><h4 class='mt-2'>".$usernamea."</h4>
                                        <br><p>".$thepost."</p>
                                        <small>".$timestamp."</small><br><br>
                                        <button type='button' class='btn btn-primary' data-toggle='collapse' data-html='true' data-target='#replies".$num."'>View Replies</button>
                                        ";
                                      if($usernamea == $username){
                                              
                                        echo "<div id='replies".$num."' class='collapse'>";
                                        if (isset($comments)){
                                                $numofcomments = count($comments);
                                                $commentnum = 0;
                                                while ($commentnum != $numofcomments){
                                                        echo $comments[$commentnum];
                                                        $commentnum = $commentnum+1;
                                                }
                                        }
                                        echo "
                                        </div>
                                        <div class='mx-auto text-center' style='width:50%;'>
                                                <div class='text-right'>
                                                <form action='' method='post'>
                                                        <br><textarea placeholder='Reply'class='form-control rounded-0' id='makepost' name='makecomment' rows='2'></textarea>
                                                        <input type='hidden' id='postnum' name='postnum' value='".$postnumber."'>
                                                        <input type='hidden' id='recipient' name='recipient' value='".$usernamea."'>
                                                        <input type='submit' value='Submit'>
                                                </form>
                                                </div>
                                        </div>
                                  
                                <br>";
                                $num = ($num +1);
                        }
                        echo "</div></div></div>";
                }}
                $num = 0;
	if(isset($_POST["makecomment"]) AND isset($_POST["postnum"]) AND isset($_POST["recipient"])){
			$post = $_POST["makecomment"];
			$postnum = $_POST["postnum"];
			$recipient = $_POST["recipient"];
			echo "<script>console.log('Making Comment')</script>";
			$commentIt = "INSERT INTO comment(sender, recipient,  message, message_datetime, post_num) values('$signedin', '$recipient', '$post', NOW(), '$postnum');";
			if(mysqli_query($connection, $commentIt)){
					echo "<script>console.log('Post Successful')</script>";
					echo "<script>window.location = '/melodymate/profile.php?user=".$username."'</script>";
				} 
			else{
				echo "<script>console.log(ERROR: Could not able to execute".$commentIt.mysqli_error($connection).")</script>";
			}
			echo "
				";
		}
	}
	else{
		echo "
		<script>window.location = '/melodymate/home.php'</script>";
	}
?>
