<?php
session_start();
include_once('header.php');
echo "<br><div class='text-center'><div class='mx-auto' style='width: 75%;'><h2>Upload Your Music</h1><br>";
if(isset($_SESSION["username"])){
	$username = $_SESSION['username'];
	echo"<h5 style='color:red;'>Supported Media Formats Include: MP3, WAV, and OGG</h5>";
	if(!isset($_POST['mediatype'])){
		$media_form = "
				<div class='form-group mb-3'>
					<form action='' method='post'>
						<div class='form-row'>
							<div class='col'>
								<input class='form-control' placeholder='Media Name' type='text' name='media_name'>
							</div>
							<div class='col'>
								<select class='form-control' placeholder='Media Type' name='mediatype'>
									<option value=''>Media Type</option>
									<option value='album'>Album</option>
									<option value='track'>Track</option>
								</select>
							</div>
						</div>
						<br>
						<input type='submit' value='Submit'>
					</form>
				</div>
			</div>
			</div>";
			echo $media_form;
	}
	$tracknum= 1;
	if(isset($_POST['media_name']) AND isset($_POST['mediatype']) AND !isset($_POST['album_track_name_1']) AND !isset($_POST['album_track_1'])){
		$media_name = addslashes($_POST['media_name']);
		$mediatype = addslashes($_POST['mediatype']);
		$tracknoform = "";
		if($mediatype == "album") {
			$tracknoform = "
				<div class='row'>
					<div class='col'>
						<input class='form-control' placeholder='Number of Tracks' type='text' name='track_count'>
					</div>
				</div>
			";
			$media_form = "
			<div class='text-center'>
				<div class='form-group mb-3'>
					<form action='' method='post'>
						<div class='row'>
							<div class='col'>
								<input class='form-control' placeholder='Media Name' type='text' name='media_name' value='".$media_name."'>
							</div>
							<div class='col'>
								<select class='form-control' placeholder='Media Type' name='mediatype' value='".$mediatype."'>
									<option>Album</option>
								</select>
							</div>
						</div><br>
						".$tracknoform."
						<br>
						<input type='submit' value='Submit'>
					</form>
				</div>
			</div>
			</div>";
			echo $media_form;
		}
		if($mediatype == "track") {
			$thetrackform = 
			"<div class='row'>
						<div class='col'>
							<label class='btn btn-secondary' for='track'>Choose File <i class='fa fa-upload' style='color: turquoise;'></i></label><input type='file' id='track' name='track' style='display:none'/>
						</div>
					</div>
					<br>
			<div class='row'>
				<div class='col'>
					<label for='description'>Description:</label>
					<textarea class='form-control rounded-0' id='description' name='track_description' rows='3'></textarea>
				</div>
			</div>
			<br>
			<div class='row'>
				<div class='col'>
					<input class='form-control' placeholder='Genre' type='text' name='track_genre'>
				</div>
				<div class='col'>
					<label class='btn btn-secondary' for='trackart'>Track Art <i class='fa fa-upload' style='color: turquoise;'></i></label><input type='file' id='trackart' name='trackart' style='display:none'/>
				</div>
			</div><br>
			";
			$media_form = "
			<div class='text-center'>
				<div class='form-group mb-3'>
					<form action='' method='post' enctype='multipart/form-data'>
						<div class='row'>
							<div class='col'>
								<input class='form-control' placeholder='Media Name' type='text' name='media_name' value='".$media_name."'>
							</div>
							<div class='col'>
								<select class='form-control' placeholder='Media Type' name='mediatype' value='".$mediatype."'>
									<option>Track</option>
								</select>
							</div>
						</div><br>
						".$thetrackform."
						<br>
						<input type='submit' value='Submit'>
					</form>
				</div>
			</div>
			</div>";
			echo $media_form;
		}
	}
	if(isset($_POST['track_count']) AND !isset($_POST['album_track_name_1']) AND !isset($_POST['album_track_1'])){
		$trackcount = intval($_POST['track_count']);
		$mediatype = addslashes($_POST['mediatype']);
		$medianame = addslashes($_POST['media_name']);
		$create_form = 'Yes';
		$trackinfo_form = "";
		while($tracknum-1 != $trackcount AND $create_form == 'Yes'){
			$trackinfo_form = $trackinfo_form."
					<div class='row'>
						<div class='col'>
							<input class='form-control' placeholder='Track ".$tracknum."' type='text' name='album_track_name_".$tracknum."'>
						</div>
						<div class='col'>
							<label class='btn btn-secondary' for='album_track_".$tracknum."'>Choose File <i class='fa fa-upload' style='color: turquoise;'></i></label><input type='file' id='album_track_".$tracknum."' name='album_track_".$tracknum."' style='display:none'/>
						</div>
					</div><br>";
			
			$tracknum = $tracknum+1;
		}
		$trackinfo_form = $trackinfo_form."
					<div class='row'>
						<div class='col'>
							<label for='description'>Description:</label>
							<textarea class='form-control rounded-0' id='description' name='album_description' rows='3'></textarea>
						</div>
					</div>
					<br>
					<div class='row'>
						<div class='col'>
							<input class='form-control' placeholder='Genre' type='text' name='album_genre'>
						</div>
						<div class='col'>
							<label class='btn btn-secondary' for='albumart'>Album Art <i class='fa fa-upload' style='color: turquoise;'></i></label><input type='file' id='albumart' name='albumart' style='display:none'/>
						</div>
					</div><br>
					";
		$tracknoform = "
				<div class='row'>
					<div class='col'>
						<input class='form-control' placeholder='Number of Tracks' type='text' name='track_count' value='".$trackcount."'>
					</div>
				</div><br>
			";
		$media_form = "
			<div class='text-center'>
				<div class='form-group mb-3'>
					<form action='' method='post' enctype='multipart/form-data' >
						<div class='row'>
							<div class='col'>
								<input class='form-control' placeholder='Media Name' type='text' name='media_name' value='".$medianame."'>
							</div>
							<div class='col'>
								<select class='form-control' placeholder='Media Type' name='mediatype' value='".$mediatype."'>
									<option value='album'>Album</option>
								</select>
							</div>
						</div><br>
						".$tracknoform."
						".$trackinfo_form."
						<input type='submit' value='Submit'>
					</form>
				</div>
			</div>
			</div>";
		echo $media_form;
	}
	$error="no";
	if(isset($_POST['media_name']) AND isset($_FILES['track']) AND isset($_FILES['trackart']) AND $error=="no"){
		$connection = mysqli_connect("localhost", "root", "MB1Uf5XDVr5MhN","melody_mate");
		if($connection == false){
			die("ERROR: Could not connect. " . mysqli_connect_error());
		}
		$track_name  = addslashes($_POST['media_name']);
		$description = null;
		$genre = null;
		if(isset($_POST['track_genre'])){
			$genre = addslashes($_POST['track_genre']);
		}
		if(isset($_POST['track_description'])){
			$description = addslashes($_POST['track_description']);
		}
		$date = date("MdYGi");
		$files_dir = "/var/www/html/melodymate/media/".$username."/".$track_name.$date."/";
		$filename = basename($_FILES['trackart']["name"]);
		$uploadOk = 1;
		$uploaded = 0;
		$file_identity = "track_art";
		$file = $files_dir . $filename;
		$imageFileType = strtolower(pathinfo($file,PATHINFO_EXTENSION));
		// Check if image file is a actual image or fake image
		if(isset($_POST["submit"])) {
		  $check = getimagesize($_FILES['trackart']["tmp_name"]);
		  if($check !== false) {
			echo "File is an image - " . $check["mime"] . ".";
			$uploadOk = 1;
		  } else {
			echo "File is not an image.";
			$error="yes";
			$uploadOk = 0;
		  }
		}

		// Allow certain file formats
		if($imageFileType != "jpg" && $imageFileType != "jpeg" && $imageFileType != "png") {
		  echo "Sorry, only JPG, JPEG, & PNG files are allowed.";
		  $error="yes";  
		  $uploadOk = 0;
		}

		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) {
		  echo "Sorry, your Album Art file was not uploaded.<br><br>";
		  $error="yes";
		  // if everything is ok, try to upload file
		} 
		else {
		  if(isset($_SESSION['username'])){
			if(!file_exists($files_dir)){
			  mkdir($files_dir, 0777, true);
			}
		  }
		  if (move_uploaded_file($_FILES["trackart"]["tmp_name"], $file)) {
			echo "The file ". $filename. " is uploading.<br>";
			$media_uploaded = 1;
		  } 
		  else {
			echo "Sorry, there was an error uploading your file.";
			$error="yes";
			$media_uploaded= 0;
		  }
		}
		if($media_uploaded == 1) {
			$sqluploader = "INSERT INTO files(name, username, identity) values('$filename', '$username', '$file_identity');";
			if(mysqli_query($connection, $sqluploader)){
				echo "File ". $filename." Successfully Uploaded<br>";
				$sql = "SELECT id FROM files WHERE name = ? AND identity = ? AND username = ?";
				$stmt = $connection->prepare($sql); 
				$stmt->bind_param("sss", $filename, $file_identity, $username);
				$stmt->execute();
				$result = $stmt->get_result(); // get the mysqli result
				while ($row= $result->fetch_assoc()) {
					$trackart_fileid = $row['id'];
				}
			} 
			else{
				echo "ERROR: Could not able to execute $sqluploader. " . mysqli_error($connection);
				$error="yes";
			}
		}
		
		$filename = basename($_FILES["track"]["name"]);
		$mediatype = "track";
		$media_file = $files_dir . $filename;
		$songFileType = strtolower(pathinfo($media_file,PATHINFO_EXTENSION));
		// Allow certain file formats
		if($songFileType != "mp3" && $songFileType != "wav" && $songFileType != "ogg") {
			echo "Sorry, only MP3, WAV & OGG files are allowed.";
			$error="yes";
			$uploadOk = 0;
		}

		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) {
			echo "Sorry, your Song file was not uploaded.<br><br>";
			$error="yes";
		// if everything is ok, try to upload file
		} 
		else {
			if(isset($_SESSION['username'])){
			if(!file_exists($files_dir)){
				mkdir($files_dir, 0777, true);
			}
			}
			if (move_uploaded_file($_FILES['track']["tmp_name"], $media_file)){ 
			echo "The file ". $filename. " is uploading.<br>";
			$media_uploaded = 0;
			}
			else {
			echo "Sorry, there was an error uploading your file.";
			$error="yes";
			$media_uploaded= 0;
			}
		}
		if($media_uploaded == 1) {
			$sqluploader = "INSERT INTO files(name, username, identity) values('$filename', '$username', '$mediatype');";
			if(mysqli_query($connection, $sqluploader)){
				echo "File ". $filename." Successfully Uploaded<br>";
				$identitym = "track";
				$sql2 = "SELECT id FROM files WHERE name = ? AND identity = ? AND username = ?";
				$stmt2 = $connection->prepare($sql2); 
				$stmt2->bind_param("sss", $filename, $identitym, $username);
				$stmt2->execute();
				$result = $stmt2->get_result(); // get the mysqli result
				while ($row= $result->fetch_assoc()) {
					$mediafile = $row['id'];
				}
				$mediauploader = "INSERT INTO media(media_name, media_desc, media_genre, media_file, media_type, username, media_img) 
				values('$track_name', '$description', '$genre', '$mediafile', '$mediatype', '$username', '$trackart_fileid')";
			} 
			else{
				echo "ERROR: Could not able to execute $sqluploader. " . mysqli_error($connection);
				$error="yes";
			}
			if(mysqli_query($connection, $mediauploader)){
				echo "Media for File ". $filename." Successfully Uploaded<br>";
			} 
			else{
				echo "ERROR: Could not able to execute $mediauploader. " . mysqli_error($connection);
				$error="yes";
			}
		}
	}
	if(isset($_POST['album_track_name_1']) AND isset($_FILES['album_track_1']) AND isset($_POST['track_count'])
		AND isset($_POST['media_name']) AND isset($_FILES['albumart']) AND $error=="no"){
		$connection = mysqli_connect("localhost", "root", "MB1Uf5XDVr5MhN","melody_mate");
		if($connection == false){
			die("ERROR: Could not connect. " . mysqli_connect_error());
		}
		$description = null;
		$genre = null;
		if(isset($_POST['album_genre'])){
			$genre = addslashes($_POST['album_genre']);
		}
		if(isset($_POST['album_description'])){
			$description = addslashes($_POST['album_description']);
		}
		$date = date("MdYGi");
		$medianame = addslashes($_POST['media_name']);
		$files_dir = "/var/www/html/melodymate/media/".$username."/".$medianame.$date."/";
		$filename = basename($_FILES['albumart']["name"]);
		$uploadOk = 1;
		$uploaded = 0;
		$file_identity = "album_art";
		$file = $files_dir . $filename;
		$imageFileType = strtolower(pathinfo($file,PATHINFO_EXTENSION));
		// Check if image file is a actual image or fake image
		if(isset($_POST["submit"])) {
		  $check = getimagesize($_FILES['albumart']["tmp_name"]);
		  if($check !== false) {
			echo "File is an image - " . $check["mime"] . ".";
			$uploadOk = 1;
		  } else {
			echo "File is not an image.";
			$error="yes";
			$uploadOk = 0;
		  }
		}

		// Allow certain file formats
		if($imageFileType != "jpg" && $imageFileType != "jpeg" && $imageFileType != "png") {
		  echo "Sorry, only JPG, JPEG, & PNG files are allowed.";
		  $error="yes";
		  $uploadOk = 0;
		}

		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) {
		  echo "Sorry, your Album Art file was not uploaded.<br><br>";
		  $error="yes";
		  // if everything is ok, try to upload file
		} 
		else {
		  if(isset($_SESSION['username'])){
			if(!file_exists($files_dir)){
			  mkdir($files_dir, 0777, true);
			}
		  }
		  if (move_uploaded_file($_FILES["albumart"]["tmp_name"], $file)) {
			echo "The file ". $filename. " is uploading.<br>";
			$media_uploaded = 1;
		  } 
		  else {
			echo "Sorry, there was an error uploading your file.";
			$error="yes";
			$media_uploaded= 0;
		  }
		}
		if($media_uploaded == 1) {
			$sqluploader = "INSERT INTO files(name, username, identity) values('$filename', '$username', '$file_identity');";
			if(mysqli_query($connection, $sqluploader)){
				echo "File ". $filename." Successfully Uploaded<br>";
				$sql = "SELECT id FROM files WHERE name = ? AND identity = ? AND username = ?";
				$stmt = $connection->prepare($sql); 
				$stmt->bind_param("sss", $filename, $file_identity, $username);
				$stmt->execute();
				$result = $stmt->get_result(); // get the mysqli result
				while ($row= $result->fetch_assoc()) {
					$albumart_fileid = $row['id'];
				}
			} 
			else{
				echo "ERROR: Could not able to execute $sqluploader. " . mysqli_error($connection);
				$error="yes";
			}
		}
		$trackcount = intval($_POST["track_count"]);
		$create_form = 'No';
		$tracknum = 1;
		$album_track_names = [];
		$filenames = [];
		$trackcountt = $_POST['track_count'];
		$albumcreator = "INSERT INTO album(album_name, album_desc, album_genre, username, album_art, timestamp, album_location, numoftracks) values('$medianame', '$description',
		'$genre', '$username', '$albumart_fileid', NOW(), '$files_dir', '$trackcountt');";
		$mediatype = 'album_track';
		if(mysqli_query($connection, $albumcreator)){
			echo "Album ".$medianame." Created<br>";
		} 
		else{
			echo "ERROR: Could not able to execute $albumcreator. " . mysqli_error($connection);
			$error="yes";
		}
		$sql = "SELECT album_num FROM album WHERE album_name = ? AND username = ?";
		$stmt = $connection->prepare($sql); 
		$stmt->bind_param("ss", $medianame, $username);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$album_num = $row['album_num'];
		}
		while($tracknum-1 != $trackcount AND $create_form == 'No'){
			$num = $tracknum-1;
			$album_track_names[($tracknum-1)] = $_POST["album_track_name_".$tracknum];
			$filenames[$num] = basename($_FILES["album_track_".$tracknum]["name"]);
			$uploadOk = 1;
			$media_uploaded = 0;
			$file_identity = "media_".$album_num;
			$media_file = $files_dir . $filenames[($tracknum-1)];
			$songFileType = strtolower(pathinfo($media_file,PATHINFO_EXTENSION));
			// Allow certain file formats
			if($songFileType != "mp3" && $songFileType != "wav" && $songFileType != "ogg") {
			  echo "Sorry, only MP3, WAV & OGG files are allowed.";
			  $error="yes";
			  $uploadOk = 0;
			}

			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
			  echo "Sorry, your Song file was not uploaded.<br><br>";
			  $error="yes";
			// if everything is ok, try to upload file
			} 
			else {
			  if(isset($_SESSION['username'])){
				if(!file_exists($files_dir)){
				  mkdir($files_dir, 0777, true);
				}
			 }
			if (move_uploaded_file($_FILES["album_track_".$tracknum]["tmp_name"], $media_file)) {
				echo "The file ". $filenames[($tracknum-1)]. " is uploading.<br>";
				$media_uploaded = 1;
			  } 
			  else {
				echo "Sorry, there was an error uploading your file.";
				$error ="yes";
				$media_uploaded= 0;
			  }
			}
			if($media_uploaded == 1) {
				$sqluploader = "INSERT INTO files(name, username, identity) values('$filenames[$num]', '$username', '$mediatype');";
				if(mysqli_query($connection, $sqluploader)){
					echo "File ". $filenames[($tracknum-1)]." Successfully Uploaded<br>";
					$identitym = "album_track";
					$sql2 = "SELECT id FROM files WHERE name = ? AND identity = ? AND username = ?";
					$stmt2 = $connection->prepare($sql2); 
					$stmt2->bind_param("sss", $filenames[$num], $identitym, $username);
					$stmt2->execute();
					$result = $stmt2->get_result(); // get the mysqli result
					while ($row= $result->fetch_assoc()) {
						$mediafile = $row['id'];
					}
					$mediauploader = "INSERT INTO media(media_name, media_desc, media_genre, album_num, track_num, media_file, media_type, username) 
					values('$album_track_names[$num]', '$description', '$genre', '$album_num', '$tracknum', '$mediafile', '$mediatype', '$username')";
				} 
				else{
					echo "ERROR: Could not able to execute $sqluploader. " . mysqli_error($connection);
					$error="yes";
				}
				if(mysqli_query($connection, $mediauploader)){
					echo "Media for File ". $filenames[($tracknum-1)]." Successfully Uploaded<br>";
				} 
				else{
					echo "ERROR: Could not able to execute $mediauploader. " . mysqli_error($connection);
					$error="yes";
				}
			}
			$tracknum = $tracknum+1;
		}
		
	}
}
?>
</div></body></html>
