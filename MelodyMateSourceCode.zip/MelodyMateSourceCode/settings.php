<?php
	session_start();
	if(isset($_SESSION["username"])){
	$username = $_SESSION["username"];
	
	$connection = mysqli_connect("localhost", "root", "MB1Uf5XDVr5MhN", "melody_mate"); 
	// Check connection
	if($connection === false){
		die("ERROR: Could not connect. " . mysqli_connect_error());
	}
	include_once('header.php');
	$deleteform = '
	<p>Confirm Deletion</p>
	<form action="#" method="post">
		<input type="submit" name="delete" class="button" value="Delete Account" /> 
	</form>
	';
	echo "
		<body>
			<div class='text-center'><div class='mx-auto' style='width: 50%;'>
			<br>
			<h4>Settings</h4>
			
			<p>Change Password:</p>
			<form action='' method='post'>
				<input class='form-control' placeholder='Old Password' type='text' name='oldpass'>
				<br>
				<input class='form-control' placeholder='New Password' type='text' name='newpass'>
				<br>
				<input class='form-control' placeholder='Confirm New Password' type='text' name='passconfirm'>
				<br>
				<input type='submit' value='Submit'>
			</form>
			<br>
			<form action='' method='post' enctype='multipart/form-data'>
				 <label class='btn btn-secondary' for='profilepic'>Change Profile Picture<i class='fa fa-upload' style='color: turquoise;'></i></label><input type='file' id='profilepic' name='profilepic' style='display:none'/>
				<input type='submit' value='Submit'>
			</form>
			<br>
			<form action='' method='post' enctype='multipart/form-data'>
				 <label class='btn btn-secondary' for='headerpic'>Change Header Picture<i class='fa fa-upload' style='color: turquoise;'></i></label><input type='file' id='headerpic' name='headerpic' style='display:none'/>
				<input type='submit' value='Submit'>
			</form>
			
			<form action='' method='post'>
				<label for='bio'>Change Bio:</label>
				<textarea class='form-control rounded-0' id='bio' name='bio' rows='3'></textarea>
				<input type='submit' value='Submit'>
			</form>
			<br>
			<a href='#' title='Account Deletion' data-toggle='popover' data-trigger='focus' data-placement='left' data-html='yes' data-content='
			".$deleteform."
			'><button type='button' class='btn btn-primary btn-sm'>Delete Account</button></a>
			<br><br>
	";
	if (isset($_POST['delete'])){
		$accounthomicide = "DELETE FROM user WHERE username = ?";
		$stmt = $connection->prepare($accounthomicide); 
		$stmt->bind_param("s", $username);
		$stmt->execute();
		echo "<script>window.location = '/melodymate/index.php'</script>";
	}
	if(isset($_POST["bio"])){
		$bio = addslashes(nl2br($_POST["bio"]));
		$sql = "UPDATE user SET profile_bio = ? WHERE username = ?;";
		$stmt = $connection->prepare($sql); 
                $stmt->bind_param("ss", $bio, $username);
                if($stmt->execute()){
			echo "<br><div class='alert alert-success' role='alert'>Bio Successfully Changed</div>";
		}
		else{
			 echo "<br><div class='alert alert-success' role='alert'>Error: Bio Not Changed</div>";
		}
	}
	if (isset($_POST['oldpass']) AND isset($_POST['newpass']) AND isset($_POST['passconfirm'])){
		$g2g = 1;
		$currentpass = "";
		$oldpass = addslashes($_POST['oldpass']);
		$newpass = addslashes($_POST['newpass']);
		$passconfirm = $_POST['passconfirm'];
		$sql = "SELECT password FROM user WHERE username = ?";
		$stmt = $connection->prepare($sql); 
		$stmt->bind_param("s", $username);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$currentpass = $row['password'];
		}
		if ($newpass != $passconfirm){
			echo "<p class='text-danger'>Passwords Do Not Match</p>";
			$g2g = 0;
		}
		if ($oldpass != $currentpass){
			echo "<p class='text-danger'>Incorrect Current Password</p>";
			$g2g = 0;
		}
		if ($g2g == 1){
			$sql = "UPDATE user SET password = ? WHERE username = ?";
			$stmt = $connection->prepare($sql); 
			$stmt->bind_param("ss", $newpass, $username);
			$stmt->execute();
			echo "<p class='text-success'>Password Change Successful</p>";
		}
	}
	if (isset($_FILES["profilepic"])){
		        $profilepic_dir = "/var/www/html/melodymate/profilepics/".$username."/";
                        $profilepic_file = $profilepic_dir . basename($_FILES["profilepic"]["name"]);
                        $profilepic_filename = basename( $_FILES["profilepic"]["name"]);
                        $uploadOk = 1;
                        $profilepic_uploaded = 0;
                        $file_identity = "profilepic";
                        $imageFileType = strtolower(pathinfo($profilepic_file,PATHINFO_EXTENSION));
                        // Check if image file is a actual image or fake image
                        if(isset($_POST["submit"])) {
                          $check = getimagesize($_FILES["profilepic"]["tmp_name"]);
                          if($check !== false) {
                                echo "<br><div class='alert alert-success' role='alert'>File is an image - " . $check["mime"] . ".</div>";
                                $uploadOk = 1;
                          } 
			else {
                                echo "<br><div class='alert alert-danger' role='alert'>
                                File is not an image.
                                </div>";
                                $uploadOk = 0;
                          }
                        }

                        // Allow certain file formats
                        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                        && $imageFileType != "gif" ) {
                          echo "<br><div class='alert alert-danger' role='alert'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</div>";
                          $uploadOk = 0;
                        }

                        // Check if $uploadOk is set to 0 by an error
                        if ($uploadOk == 0) {
                          echo "<br><div class='alert alert-danger' role='alert'>Sorry, your Profile Pic file was not uploaded.</div>";
                        // if everything is ok, try to upload file
                        } 
                        else {
                          if (move_uploaded_file($_FILES["profilepic"]["tmp_name"], $profilepic_file)) {
                                echo "<br><div class='alert alert-success' role='alert'>The file ". $profilepic_filename. " is uploading.</div>";
                                $profilepic_uploaded = 1;
                          } 
                          else {
                                echo "<br><div class='alert alert-danger' role='alert'>Sorry, there was an error uploading your file.</div>";
                                $profilepic_uploaded= 0;
                          }
                        }
                        if($profilepic_uploaded == 1) {
                                $file_identity = "profilepic";
                                $sqluploader = "UPDATE files SET name = ? WHERE identity = ? AND username = ?;";
								$stmt = $connection->prepare($sqluploader); 
								$stmt->bind_param("sss", $profilepic_filename, $file_identity, $username);
                                if($stmt->execute()){
                                        echo "<br><div class='alert alert-success' role='alert'>File ". $profilepic_filename." Successfully Uploaded</div>";
                                } 
                                else{
                                        echo "<br><div class='alert alert-danger' role='alert'>ERROR: Could not able to execute $sqluploader. " . mysqli_error($connection)."</div>";
                                }
								$accountupdater = "UPDATE user SET profile_pic =  (SELECT id FROM files WHERE username = ? AND identity = 'profilepic') WHERE username = ?;";
								$stmt = $connection->prepare($accountupdater); 
								$stmt->bind_param("ss", $username, $username);
                                if($stmt->execute()){
                                        echo "<br><div class='alert alert-success' role='alert'>Account Updated</div>";
                                } 
                                else{
                                        echo "<br><div class='alert alert-danger' role='alert'>ERROR: Could not able to execute $accountupdater. " . mysqli_error($connection)."</div>";
        			}                
			}
	}
	             if (isset($_FILES["headerpic"])){
                        $headerpic_dir = "/var/www/html/melodymate/headerpics/".$username."/";
                        $headerpic_file = $headerpic_dir . basename($_FILES["headerpic"]["name"]);
                        $headerpic_filename = basename( $_FILES["headerpic"]["name"]);
                        $uploadOk = 1;
                        $headerpic_uploaded = 0;
                        $file_identity = "headerpic";
                        $imageFileType = strtolower(pathinfo($headerpic_file,PATHINFO_EXTENSION));
                        // Check if image file is a actual image or fake image
                        if(isset($_POST["submit"])) {
                          $check = getimagesize($_FILES["headerpic"]["tmp_name"]);
                          if($check !== false) {
                                echo "<br><div class='alert alert-success' role='alert'>File is an image - " . $check["mime"] . ".</div>";
                                $uploadOk = 1;
                          } 
                        else {
                                echo "<br><div class='alert alert-danger' role='alert'>
                                File is not an image.
                                </div>";
                                $uploadOk = 0;
                          }
                        }

                        // Allow certain file formats
                        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                        && $imageFileType != "gif" ) {
                          echo "<br><div class='alert alert-danger' role='alert'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</div>";
                          $uploadOk = 0;
                        }

                        // Check if $uploadOk is set to 0 by an error
						if ($uploadOk == 0) {
                          echo "<br><div class='alert alert-danger' role='alert'>Sorry, your header Pic file was not uploaded.</div>";
                        // if everything is ok, try to upload file
                        } 
                        else {
                          if (move_uploaded_file($_FILES["headerpic"]["tmp_name"], $headerpic_file)) {
                                echo "<br><div class='alert alert-success' role='alert'>The file ". $headerpic_filename. " is uploading.</div>";
                                $headerpic_uploaded = 1;
                          } 
                          else {
                                echo "<br><div class='alert alert-danger' role='alert'>Sorry, there was an error uploading your file.</div>";
                                $headerpic_uploaded= 0;
                          }
                        }
                        if($headerpic_uploaded == 1) {
                                $file_identity = "headerpic";
                                $sqluploader = "UPDATE files SET name = ? WHERE identity = ? AND username = ?;";
                                                                $stmt = $connection->prepare($sqluploader); 
                                                                $stmt->bind_param("sss", $headerpic_filename, $file_identity, $username);
                                if($stmt->execute()){
                                        echo "<br><div class='alert alert-success' role='alert'>File ". $headerpic_filename." Successfully Uploaded</div>";
                                } 
                                else{
                                        echo "<br><div class='alert alert-danger' role='alert'>ERROR: Could not able to execute $sqluploader. " . mysqli_error($connection)."</div>";
                                }
                                                                $accountupdater = "UPDATE user SET header_pic =  (SELECT id FROM files WHERE username = ? AND identity = 'headerpic') WHERE username = ?;";
                                                                $stmt = $connection->prepare($accountupdater); 
                                                                $stmt->bind_param("ss", $username, $username);
                                if($stmt->execute()){
                                        echo "<br><div class='alert alert-success' role='alert'>Account Updated</div>";
                                } 
                                else{
                                        echo "<br><div class='alert alert-danger' role='alert'>ERROR: Could not able to execute $accountupdater. " . mysqli_error($connection)."</div>";
                                }                
                        }
        }
	echo "
		</div></div>
	</body>
	</html>";
	}
	?>


