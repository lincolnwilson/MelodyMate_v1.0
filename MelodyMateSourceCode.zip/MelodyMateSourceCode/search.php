<html lang="en">
	<head>
		<title>Bootstrap Example</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
	</head>
<?php
	if(isset($_POST['search_entry'])){
		include_once('header.php');
		echo "<br><div class='container mt-3'><div class='text-center'>
			<div class='mx-auto' style='width: 30%;'>";
		$search_entry = '%'.$_POST['search_entry'].'%';
		
		$connection = mysqli_connect('localhost', 'root', 'MB1Uf5XDVr5MhN', 'melody_mate');
			 
		// Check connection
		if($connection === false){
			die('ERROR: Could not connect. ' . mysqli_connect_error());
		}
		
		$userfinder = 'SELECT username, profile_pic FROM user WHERE username LIKE ?;';
		$profilepicfinder = 'SELECT name FROM files WHERE id = ?;';
		$stmt = $connection->prepare($userfinder); 
		if (!$stmt) {
			throw new Exception($connection->error, $connection->errno);
		}
		$stmt->bind_param('s', $search_entry);
		if (!$stmt->execute()) {
			throw new Exception($stmt->error, $stmt->errno);
		}
		$result = $stmt->get_result(); // get the mysqli result
		
		if ($result->num_rows > 0) {
			while ($row= $result->fetch_assoc()) {
				$username = $row['username'];
				$profilepic = $row['profile_pic'];
				$stmt2 = $connection->prepare($profilepicfinder);
				$stmt2->bind_param('i', $profilepic);
				$stmt2->execute();
				$result2= $stmt2->get_result();
				while($row2=$result2->fetch_assoc()) {
					$filename = $row2['name'];
				}
				echo "
					<div class='media'>
						<img src='/melodymate/profilepics/".$username."/".$filename."' class='align-self-start mr-3 rounded-circle' style='width:100px;height:100px;'>
					  <div class='media-body'>
						<h4>".$username."</h4>
						<a href='/melodymate/profile.php?user=".$username."'>View Profile</a>
					  </div>
					</div>
				<br><hr/><br>";
			}
			echo "</div></div></div>";
		}
		else {
			echo 'No Results';
		}
	}
	else {
		echo "</div></div></div><script>window.location = '/melodymate/home.php'</script>";
	}
?>
