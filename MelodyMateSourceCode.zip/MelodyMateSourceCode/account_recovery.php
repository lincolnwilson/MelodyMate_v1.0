<html lang="en">
	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
		<link rel='stylesheet' href='styles.css'>
		<title>MelodyMate</title>
	</head>
	<body>
		<?php
			include_once('index-header.php');
		?>
		<div class='text-center'>
		<div class='mx-auto' style='width: 60%;'>
			<br><h2>Account Recovery</h2>
<?php
	if(isset($_POST['username'])){
		echo "Security Question: <br>";
		$username = $_POST['username'];
		$connection = mysqli_connect("localhost", "root", "MB1Uf5XDVr5MhN", "melody_mate");
		 
		// Check connection
		if($connection === false){
			die("ERROR: Could not connect. " . mysqli_connect_error());
		}
		$sql = "SELECT security_q FROM user WHERE username = ?;";
		$stmt = $connection->prepare($sql); 
		$stmt->bind_param("s", $username);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			echo $row['security_q'];
		}
	}
	mysqli_close($connection);
?>
			<br><br><form action='/melodymate/get_password.php' method='post'>
				<div class="row">
					<div class="col">
						<input class="form-control" placeholder="Answer" type="text" name="security_a">
					</div>
					<div class="col">
						<input class="form-control" placeholder="Username"  type="varchar" name="username">
					</div>
				</div>
				<br>
				<input type='submit' value='Submit'>
			</form>
			<br><a href='/melodymate/index.php'>Login</a>
		</div>
		</div>
		<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
	</body>
</html>
