<?php
session_start();
if(isset($_GET["album"]) AND isset($_SESSION["username"])){
	$connection = mysqli_connect("localhost", "root", "MB1Uf5XDVr5MhN", "melody_mate");
	// Check connection
	if($connection === false){
		die("ERROR: Could not connect. " . mysqli_connect_error());
	}
	$trash = $_GET["album"];
	$sql = "DELETE FROM album WHERE album_num = ?;";
	$stmt = $connection->prepare($sql);
	$stmt->bind_param("s", $trash);
	$stmt->execute();
	echo "<script>window.location = '/melodymate/managemedia.php?trashed=1'</script>";
}
?>
