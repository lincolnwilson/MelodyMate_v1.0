<!DOCTYPE html>
<html lang="en">
	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	</head>
	<body>
		<?php
		include_once('index-header.php');
		?>
		<div class='text-center'>
		<div class='mx-auto' style='width: 55%;'>
			<br><br>
			<h2>Welcome to MelodyMate!</h2><br>
			<p><i>Connect with Local Musicians in Connecticut!</i></p><br>
			<div class="form-group mb-3">
				<form action="/melodymate/login.php" method="post">
					<div class="row">
						<div class="col">
						<input class="form-control" placeholder="Username"type="text" name="username">
						</div>
					</div>
					<br>
					<div class="row">
						<div class="col">
						<input class="form-control" placeholder="Password" type="password" name="password">
						</div>
					</div>
					<br>
					<input type="submit" value="Submit">
				</form>
			</div>
			</div>
			<a href="/melodymate/forgotpass.php"><h5>Forgot Password</h5></a>
			<br>
			<a href="/melodymate/account_form.php"><h5>Create Account</h5></a>
			<br>
			<p>MelodyMate is in development. If you encounter bugs please contact the developer.</p>
			<a href="https://trello.com/b/qk26301n/melodymate"><p>Here is the Trello Development Board</p></a>
			<p>This site was made in part for a University final project, please take this survey.</p>
			<a href="https://www.surveymonkey.com/r/F8XB8D5">Here is a Link to the Survey Monkey Survey</a><br><br>
		</div>
		</div>
	</body>
</html>
