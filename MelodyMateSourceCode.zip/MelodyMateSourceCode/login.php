<?php
	session_start();
	include_once('index-header.php');
	echo "<div class='text-center'>";
	if(!empty($_POST['username']) and !empty($_POST['password'])) {
		$username = $_POST['username'];
		$password = $_POST['password'];
		$usercheck = "";
		$passcheck = "";
		$connection = mysqli_connect("localhost", "root", "MB1Uf5XDVr5MhN", "melody_mate");
		 
		// Check connection
		if($connection === false){
			die("ERROR: Could not connect. " . mysqli_connect_error());
		}
		$sql = "SELECT username, password FROM user WHERE username = ? AND password = ?";
		$stmt = $connection->prepare($sql); 
		$stmt->bind_param("ss", $username, $password);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$usercheck = $row['username'];
			$passcheck = $row['password'];
		}
		if (($username == $usercheck) AND ($password == $passcheck)) {
			$_SESSION["username"] = $username;
			echo "
			</div>
			<script>window.location.href = '/melodymate/home.php';</script>
			";
		}
		else {
			echo"<br><div class='alert alert-danger' role='alert'>
				Username and/or Password Incorrect!
			</div>";
		}
	}
	else {
		echo"<br><div class='alert alert-danger' role='alert'>
			No Username and/or Password Entered!
			</div>";
	}
	echo "</div>";
	include_once('index.php');
?>
