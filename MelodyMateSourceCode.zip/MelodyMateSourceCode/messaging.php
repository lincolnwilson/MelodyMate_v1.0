<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<link rel='stylesheet' href='styles.css'>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src='https://code.jquery.com/jquery-3.5.1.slim.min.js' integrity='sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj' crossorigin='anonymous'></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src='https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js' integrity='sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI' crossorigin='anonymous'></script>
	 <meta http-equiv="refresh" content="1">
</head>
<?php 
//CHATROOM
if(isset($_GET['chat']) AND isset($_GET['page']) AND isset($_GET['username'])){
	$connection = mysqli_connect("localhost", "root", "MB1Uf5XDVr5MhN", "melody_mate");
	// Check connection
	if($connection === false){
		die("ERROR: Could not connect. " . mysqli_connect_error());
	}
	$chatrecipient = $_GET['chat'];
	$username = $_GET["username"];
	$page=$_GET['page'];
	echo '<div class="container mt-3"><div class="text-center">
	<div class="mx-auto" style="width: 30%;"><br>';
	$messages = [];
	$messages_ts = [];
	$sender = [];
	$recipient = [];
	$num = 0;
	$messagessql = "SELECT message, message_ts, sender, recipient FROM pm WHERE (sender = ? AND recipient = ?) OR (sender = ? AND recipient = ?) ORDER BY message_ts DESC";
	$stmt = $connection->prepare($messagessql); 
	$stmt->bind_param("ssss", $username, $chatrecipient, $chatrecipient, $username);
	$stmt->execute();
	$result = $stmt->get_result(); // get the mysqli result
	while ($row= $result->fetch_assoc()) {
		$messages[$num] = $row['message'];
		$message_ts[$num] = $row['message_ts'];
		$sender[$num] = $row['sender'];
		$recipient[$num] = $row['recipient'];
		$num = $num +1;
	}
	$nummessages = $num;
	$numberofpages = ceil($nummessages / 5);
	if ($numberofpages > 5){
		$numberofpages =5;
	}
	$num = 0;
	$identity = 'profilepic';
	$profilepicfinder = 'SELECT name FROM files WHERE username = ? AND identity = ?;';
	if (!empty($messages)){
		if ($numberofpages == 1){
			$num =0;
			$endnum = $nummessages;
		}
		if ($numberofpages ==2 AND $page==1){
			$num =0;
			$endnum = 5;
		}
		if ($numberofpages ==2 AND $page==2){
			$num =5;
			$endnum = $nummessages;
		}
		if ($numberofpages ==3 AND $page==1){
			$num =0;
			$endnum = 5;
		}
		if ($numberofpages ==3 AND $page==2){
			$num =5;
			$endnum = 10;
		}
		if ($numberofpages ==3 AND $page==3){
			$num =10;
			$endnum = $nummessages;
		}
		if ($numberofpages ==4 AND $page==1){
			$num =0;
			$endnum = 5;
		}
		if ($numberofpages ==4 AND $page==2){
			$num =5;
			$endnum = 10;
		}
		if ($numberofpages ==4 AND $page==3){
			$num =10;
			$endnum = 15;
		}
		if ($numberofpages ==4 AND $page==4){
			$num =15;
			$endnum = $nummessages;
		}
		if ($numberofpages ==5 AND $page==1){
			$num =0;
			$endnum = 5;
		}
		if ($numberofpages ==5 AND $page==2){
			$num =5;
			$endnum = 10;
		}
		if ($numberofpages ==5 AND $page==3){
			$num =10;
			$endnum = 15;
		}
		if ($numberofpages ==5 AND $page==4){
			$num =15;
			$endnum = 20;
		}
		if ($numberofpages ==5 AND $page==5){
			$num =20;
			$endnum = 25;
		}
		while ($num != $endnum){
			$senderu = strval($sender[$num]);
			$stmt2 = $connection->prepare($profilepicfinder);
			$stmt2->bind_param('ss', $senderu,$identity);
			$stmt2->execute();
			$result2= $stmt2->get_result();
			while($row2=$result2->fetch_assoc()) {
				$filename = $row2['name'];
			}
			echo '<div class="media">';
			if ($senderu==$username){
				echo '<img class="rounded-circle mr-3" src="/melodymate/profilepics/'.$senderu.'/'.$filename.'" alt="Avatar" style="width:50px;height:50px;">
				';
			}
				echo'<div class="media-body">
				<h4 class="mt-0">'.$senderu.'</h4>
			<p>'.$messages[$num].'</p>
			<small>'.$message_ts[$num].'</small>
				</div>';
			if ($senderu!==$username){
				echo '<div class="media-right"><img class="rounded-circle mr-3" src="/melodymate/profilepics/'.$senderu.'/'.$filename.'" alt="Avatar" style="width:50px;height:50px;"></div>
				';
			}
			echo '</div><br>';
			$num++;
		}
					
		$xnum = 0;
		echo'<nav class="ml-5" aria-label="Page navigation">
			<ul class="pagination">';
			while ($xnum != $numberofpages){
			$page = $xnum+1;
			echo '<li class="page-item"><a class="page-link" href="/melodymate/messaging.php?page='.$page.'&chat='.$chatrecipient.'">'.$page.'</a></li>';
			$xnum++;
			}
			echo '</ul>
		</nav>';
	}
	else {
			echo '
			No Messages Sent<br><br>
		</div></div></div>';
	}
}
?>
