<?php
	include_once('index-header.php');
	echo "<div class='text-center'>
		<div class='mx-auto' style='width: 90%;'><br>";
	$connection = mysqli_connect("localhost", "root", "MB1Uf5XDVr5MhN","melody_mate");
	if($connection == false){
		die("ERROR: Could not connect. " . mysqli_connect_error());
	}
	if(!empty($_POST['username']) AND !empty($_POST['password'])){
		$username = addslashes($_POST["username"]);
		$password = addslashes($_POST["password"]);
		$sql = "SELECT username FROM user WHERE username=?";
		$stmt = $connection->prepare($sql); 
		$stmt->bind_param("s", $username);
		$stmt->execute();
		$result = $stmt->get_result(); // get the mysqli result
		while ($row= $result->fetch_assoc()) {
			$checkifexists = $row['username'];
		}
		if(isset($checkifexists)){
			echo "<br><div class='alert alert-danger' role='alert'>
			  Username already exists!
			</div>";
		}
		else {
			$security_q = $_POST["security_q"];
			$security_a = $_POST["security_a"];
			$bio = $_POST["bio"];
			$bio = addslashes(nl2br($bio));
			$security_q = addslashes($security_q);
			$security_a = addslashes($security_a);
			$email = addslashes($_POST["email"]);
			$profilepic_dir = "/var/www/html/melodymate/profilepics/".$username."/";
			$headerpic_dir = "/var/www/html/melodymate/headerpics/".$username."/";
			$profilepic_file = $profilepic_dir . basename($_FILES["profilepic"]["name"]);
			$headerpic_file = $headerpic_dir . basename($_FILES["headerpic"]["name"]);
			$profilepic_filename = basename( $_FILES["profilepic"]["name"]);
			$headerpic_filename = basename( $_FILES["headerpic"]["name"]);
			$uploadOk = 1;
			$profilepic_uploaded = 0;
			$headerpic_uploaded = 0;
			$file_identity = "profilepic";
			$imageFileType = strtolower(pathinfo($profilepic_file,PATHINFO_EXTENSION));
			// Check if image file is a actual image or fake image
			if(isset($_POST["submit"])) {
			  $check = getimagesize($_FILES["profilepic"]["tmp_name"]);
			  if($check !== false) {
				echo "<br><div class='alert alert-success' role='alert'>File is an image - " . $check["mime"] . ".</div>";
				$uploadOk = 1;
			  } else {
				echo "<br><div class='alert alert-danger' role='alert'>
				File is not an image.
				</div>";
				$uploadOk = 0;
			  }
			}

			// Allow certain file formats
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" ) {
			  echo "<br><div class='alert alert-danger' role='alert'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</div>";
			  $uploadOk = 0;
			}

			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
			  echo "<br><div class='alert alert-danger' role='alert'>Sorry, your Profile Pic file was not uploaded.</div>";
			// if everything is ok, try to upload file
			} 
			else {
			  if(isset($_POST['username'])){
				  mkdir('/var/www/html/melodymate/profilepics/'.$username);
			  }
			  if (move_uploaded_file($_FILES["profilepic"]["tmp_name"], $profilepic_file)) {
				echo "<br><div class='alert alert-success' role='alert'>The file ". $profilepic_filename. " is uploading.</div>";
				$profilepic_uploaded = 1;
			  } 
			  else {
				echo "<br><div class='alert alert-danger' role='alert'>Sorry, there was an error uploading your file.</div>";
				$profilepic_uploaded= 0;
			  }
			}
			$file_identity = "headerpic";
			$imageFileType = strtolower(pathinfo($headerpic_file,PATHINFO_EXTENSION));
			// Check if image file is a actual image or fake image
			if(isset($_POST["submit"])) {
			  $check = getimagesize($_FILES["headerpic"]["tmp_name"]);
			  if($check !== false) {
				echo "<br><div class='alert alert-success' role='alert'>File is an image - " . $check["mime"] . ".</div>";
				$uploadOk = 1;
			  } else {
				echo "<br><div class='alert alert-danger' role='alert'>File is not an image.</div>";
				$uploadOk = 0;
			  }
			}

			// Allow certain file formats
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" ) {
			  echo "<br><div class='alert alert-danger' role='alert'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</div>";
			  $uploadOk = 0;
			}

			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
			  echo "<br><div class='alert alert-danger' role='alert'>Sorry, your Header pic file was not uploaded.</div>";
			// if everything is ok, try to upload file
			} else {
			  if(isset($_POST['username'])){
				mkdir("/var/www/html/melodymate/headerpics/".$username);
			  }
			  if (move_uploaded_file($_FILES["headerpic"]["tmp_name"], $headerpic_file)) {
				echo "<br><div class='alert alert-success' role='alert'>The file ". $headerpic_filename. " is uploading.</div>";
				$headerpic_uploaded = 1;
			  } else {
				echo "<br><div class='alert alert-danger' role='alert'>Sorry, there was an error uploading your file.</div>";
				$headerpic_uploaded= 0;
			  }
			}
			if($profilepic_uploaded == 1) {
				$file_identity = "profilepic";
				$sqluploader = "INSERT INTO files(name, username, identity) values('$profilepic_filename', '$username', '$file_identity');";
				if(mysqli_query($connection, $sqluploader)){
					echo "<br><div class='alert alert-success' role='alert'>File ". $profilepic_filename." Successfully Uploaded</div>";
				} 
				else{
					echo "<br><div class='alert alert-danger' role='alert'>ERROR: Could not able to execute $sqluploader. " . mysqli_error($connection)."</div>";
				}
			}
			if($headerpic_uploaded == 1) {
				$file_identity = "headerpic";
				$sqluploader = "INSERT INTO files(name, username, identity) values('$headerpic_filename', '$username', '$file_identity');";
				if(mysqli_query($connection, $sqluploader)){
					echo "<br><div class='alert alert-success' role='alert'>File ". $headerpic_filename." Successfully Uploaded</div>";
				} 
				else{
					echo "<br><div class='alert alert-danger' role='alert'>ERROR: Could not able to execute $sqluploader. " . mysqli_error($connection)."</div>";
				}
			}
			if($profilepic_uploaded == 1 AND $headerpic_uploaded == 1){
				$accountcreator = "INSERT INTO user(username, password, email, security_q, security_a, profile_bio, profile_pic, header_pic, highlighted_media) 
				values ('$username', '$password', '$email', '$security_q', '$security_a', '$bio',
				(SELECT id FROM files WHERE username = '$username' AND identity = 'profilepic'),(SELECT id FROM files WHERE username = 
				'$username' AND identity = 'headerpic'), 'album');";
				$followinglist = $username."_following";
				$followerslist = $username."_followers";
				$followinglistq = "INSERT INTO list(name) values('$followinglist');";
				$followerlistq = "INSERT INTO list(name) values('$followerslist');";
				if(mysqli_query($connection, $followinglistq)){
					echo "<br><div class='alert alert-success' role='alert'>Following List Created Successfully</div>";
				}
				else{
					echo "<br><div class='alert alert-danger' role='alert'>ERROR: Could not able to execute $followinglistq. " . mysqli_error($connection)."</div>";
				}
				if(mysqli_query($connection, $followerlistq)){
					echo "<br><div class='alert alert-success' role='alert'>Follower List Created Successfully</div>";
				}
				else{
					echo "<br><div class='alert alert-danger' role='alert'>ERROR: Could not able to execute $followerlistq. " . mysqli_error($connection)."</div>";
				}
				if(mysqli_query($connection, $accountcreator)){
					echo "<br><div class='alert alert-success' role='alert'>Account Created Successfully.</div>";
				} 
				else{
					echo "<br><div class='alert alert-danger' role='alert'>ERROR: Could not able to execute $accountcreator. " . mysqli_error($connection)."</div>";
				}
			}
			else{
				echo "<br><div class='alert alert-danger' role='alert'>Profile Pic and/or Header Pic not Uploaded, unable to create account</div>";
			}
		}
	}
	else {
		echo "<div class='alert alert-danger' role='alert'>
			  No Username and/or Password Entered!
			</div>";
		echo "</div></div>";
	}
	include_once('account_form.php');
	// Close Connection
	mysqli_close($connection);
?>
</html>
