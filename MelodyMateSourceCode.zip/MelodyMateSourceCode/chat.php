<?php
	session_start();
	if(isset($_GET["page"])){
		$page = $_GET["page"];
		if(isset($_SESSION["username"])){
			$username = $_SESSION["username"];

			$connection = mysqli_connect("localhost", "root", "MB1Uf5XDVr5MhN", "melody_mate");
	
			// Check connection
			if($connection === false){
				die("ERROR: Could not connect. " . mysqli_connect_error());
			}

			// Following List id
			$listname = $username."_following";
			$sql = "SELECT list_id FROM list WHERE name = ?";
			$stmt = $connection->prepare($sql); 
			$stmt->bind_param("s", $listname);
			$stmt->execute();
			$result = $stmt->get_result(); // get the mysqli result
			while ($row= $result->fetch_assoc()) {
				$list_id = $row['list_id'];
			}

			//followlist
			$znum = 0;
			$xnum=0;
			$following = [];
			$followingfinder = "SELECT content FROM content WHERE list_id = ?";
			$stmt = $connection->prepare($followingfinder); 
			$stmt->bind_param("s", $list_id);
			$stmt->execute();
			$result = $stmt->get_result(); // get the mysqli result
			while ($row= $result->fetch_assoc()) {
				$following[$xnum] = $row['content'];
				$xnum++;
			}
			$numfollowing = $xnum;
			//followingOutput
			$follownum =0;
			$userfinder = 'SELECT username, profile_pic FROM user WHERE username = ?;';
			$profilepicfinder = 'SELECT name FROM files WHERE id = ?;';
			$followingOutput = "";
			while ($follownum != $numfollowing){
				$search_entry = $following[$follownum];
				$stmt = $connection->prepare($userfinder); 
				if (!$stmt) {
					throw new Exception($connection->error, $connection->errno);
				}
				$stmt->bind_param('s', $search_entry);
				if (!$stmt->execute()) {
					throw new Exception($stmt->error, $stmt->errno);
				}
				$result = $stmt->get_result(); // get the mysqli result
				if ($result->num_rows > 0) {
					while ($row= $result->fetch_assoc()) {
						$usernames = $row['username'];
						$profilepics = $row['profile_pic'];
						$stmt2 = $connection->prepare($profilepicfinder);
						$stmt2->bind_param('i', $profilepics);
						$stmt2->execute();
						$result2= $stmt2->get_result();
						while($row2=$result2->fetch_assoc()) {
							$filename = $row2['name'];
						}
						$followingOutput = $followingOutput.'
							<div class="media">
								<img src="/melodymate/profilepics/'.$usernames.'/'.$filename.'" class="mr-2 rounded-circle" style="width:30px; height:30px;">
								<div class="media-body">
								'.$usernames.'
								<a href="chat.php?page=1&chat='.$usernames.'">Message</a>
								</div>
							</div>
						<br><hr/><br>';
					}
				}
				$follownum = $follownum +1;
			}
		}
	}
?>
<html>
<head></head>
<body>		
	<div style='width: 100%;'>
	<?php include_once('header.php'); ?>
	</div>
	<br>
	<?php 
		$div = '<div style="height:300px;overflow-y:auto;">';
		echo "<div class='text-center'>
			<a title='Chat' tabindex='0' role='button' data-toggle='popover' data-trigger='focus' data-placement='bottom' data-html='true' data-content='".$div.$followingOutput."</div>'><button type='button' class='btn btn-primary btn-sm' style='width:250px;'>Chat (".$numfollowing.")</button></a>
		<br><br>";
		if(isset($_GET['chat'])){
		 	$chatrecipient = $_GET['chat'];
			echo "<div class='embed-responsive embed-responsive-21by9'>
			<iframe class='embed-responsive-item' src= '/melodymate/messaging.php?page=1&chat=".$chatrecipient."&username=".$username."'></iframe>
			</div>";
			echo '
			<form action="" method="post">
			<input class="form-control text-center mx-auto" placeholder="Enter Your Message" type="text" name="message" style="width:30%;">
			</form>
				';
		}
		echo '</div>';
	?>
</body>
</html>
<?php
	if (isset($_POST['message'])){
		$recipienter = $chatrecipient;
		$messager = addslashes($_POST['message']);
		$messageposter = 'INSERT INTO pm(message, recipient, sender) values(?,?,?);';
		$msgstatement = $connection->prepare($messageposter);
		$msgstatement->bind_param('sss', $messager,$recipienter,$username);
		$msgstatement->execute();
	}
?>
