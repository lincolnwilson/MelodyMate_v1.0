<?php
	session_start();
	if(isset($_SESSION["username"])){
		$username = $_SESSION["username"];
		$connection = mysqli_connect("localhost", "root", "MB1Uf5XDVr5MhN", "melody_mate");
 
		// Check connection
		if($connection === false){
			die("ERROR: Could not connect. " . mysqli_connect_error());
		}
		echo "<div style='width:100%'>";
		include_once('header.php');
		echo "</div>";
		echo "
		<body>
			<div class='mx-auto text-center' style='width:25%'>
			";
			if(isset($_GET["trashed"])){
				echo'<br><div class="alert alert-success">Album Deleted Successfully</div>';
			}
			echo "
				<br><h2>Manage Your Media</h2>
				<br><h4><a href='uploadmedia.php'><button type='button' class='btn btn-dark'>Upload New Music</button></a></h5>
				<br><h5><i>Delete Media</i></h5><br>
			";
			$num = 0;
			$albumname = [];
			$albumnums = [];
			$timestamps = [];
			$albumarts = [];
			$locations = [];
			$sql = "SELECT * FROM album WHERE username = ? ORDER BY timestamp;";
			$stmt = $connection->prepare($sql); 
			$stmt->bind_param("s", $username);
			$stmt->execute();
			$result = $stmt->get_result(); // get the mysqli result
			while ($row= $result->fetch_assoc()) {
				$albumname[$num] = $row['album_name'];
				$timestamps[$num] = $row['timestamp'];
				$albumarts[$num] = $row['album_art'];
				$albumnums[$num] = $row['album_num'];
				$locations[$num] = $row['album_location'];
				$locations[$num] = str_replace("/var/www/html","",$locations[$num]);
				$num++;
			}
			$filenames = [];
			$numofalbums = $num;
			$num = 0; 
			while($num != $numofalbums){
				$albumartfilefinder = "SELECT name FROM files WHERE id = ?;";
				$stmt = $connection->prepare($albumartfilefinder); 
				$stmt->bind_param("s", $albumarts[$num]);
				$stmt->execute();
				$result = $stmt->get_result(); // get the mysqli result
				while ($row= $result->fetch_assoc()) {
					$filenames[$num] = $row['name'];
				}
				$num++;
			}
			$num = 0;
			echo "</div>";
			echo "<div style='width:50%' class='mx-auto text-center'>";
			while($num != $numofalbums){
				echo '
					<div class="container border border-dark">
						<br><img src="'.$locations[$num].$filenames[$num].'" style="width:100px; height:100px;">
						
							<strong><p>'.$albumname[$num].'</p></strong>
							<p>'.$timestamps[$num].'</p>
							<a style="color:red;" href="/melodymate/deletealbum.php?album='.$albumnums[$num].'"><strong>Delete Album</strong></a><br><br>
					</div><br>
					
					<br>
				';
				$num++;
			}
		echo "
			</div>
		</body>
		";
	}
?>
